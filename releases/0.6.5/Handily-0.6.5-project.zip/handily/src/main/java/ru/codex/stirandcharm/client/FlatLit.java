/* Adapted from Hands-On Delight. Copyright (c) 2026 Pocky. MIT license; see LICENSE_HANDSON_DELIGHT. */
package ru.codex.stirandcharm.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;

/**
 * Items drawn on a page are icons, lit as in the inventory: every normal points up, into both of the level's lights, so a flat
 * icon is never shaded by the way the page happens to face. Since 1.20.5 the entity shader lights normals in the pose's own
 * space, and the book's items came out darker than on 1.20.1.
 */
final class FlatLit implements VertexConsumer {
    private final VertexConsumer delegate;

    private FlatLit(VertexConsumer delegate) {
        this.delegate = delegate;
    }

    static MultiBufferSource of(MultiBufferSource buffers) {
        return type -> new FlatLit(buffers.getBuffer(type));
    }

    @Override
    public VertexConsumer addVertex(float x, float y, float z) {
        delegate.addVertex(x, y, z);
        return this;
    }

    @Override
    public VertexConsumer setColor(int red, int green, int blue, int alpha) {
        delegate.setColor(red, green, blue, alpha);
        return this;
    }

    @Override
    public VertexConsumer setUv(float u, float v) {
        delegate.setUv(u, v);
        return this;
    }

    @Override
    public VertexConsumer setUv1(int u, int v) {
        delegate.setUv1(u, v);
        return this;
    }

    @Override
    public VertexConsumer setUv2(int u, int v) {
        delegate.setUv2(u, v);
        return this;
    }

    @Override
    public VertexConsumer setNormal(float x, float y, float z) {
        delegate.setNormal(0.0F, 1.0F, 0.0F);
        return this;
    }

    @Override
    public void addVertex(float x, float y, float z, int color, float u, float v, int overlay, int light, float normalX, float normalY,
            float normalZ) {
        delegate.addVertex(x, y, z, color, u, v, overlay, light, 0.0F, 1.0F, 0.0F);
    }
}
